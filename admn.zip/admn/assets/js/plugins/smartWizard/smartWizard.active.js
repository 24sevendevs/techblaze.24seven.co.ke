(function ($) {
    "use strict";
    
    /*Smart Wizard*/
    if( $('.smart-wizard').length ) {
        $('.smart-wizard').smartWizard({
            showStepURLhash: false,
        });
    }
    
})(jQuery);